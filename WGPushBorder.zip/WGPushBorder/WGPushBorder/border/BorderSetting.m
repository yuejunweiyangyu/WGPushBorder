//
//  BorderSetting.m
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BorderSetting.h"
#import "WeakDisplayView.h"

@interface BorderSetting(){
    NSString *displayText;
    UIView *controller;
}

@property (nonatomic, strong) WeakDisplayView *displayView;

@end

@implementation BorderSetting

+ (BorderSetting *)shareBorderSetting{
    static BorderSetting *border = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        border = [[self alloc] init];
    });
    return border;
}




#pragma mark     ==========================弱提示============================
- (void)showWeakDisplayView:(UIView *)viewController titleText:(NSString *)titleText{
    displayText = titleText;
    controller = viewController;
    [viewController addSubview:self.displayView];
    [self.displayView show];
    [self performSelector:@selector(hideDisplayView) withObject:self afterDelay:2];
}
- (void)hideDisplayView{
    [self.displayView hideDisplayLabel];
    self.displayView = nil;
}

- (WeakDisplayView *)displayView{
    if (!_displayView) {
        _displayView = [[WeakDisplayView alloc] initWithFrame:controller.frame titleText:displayText];
    }
    return _displayView;
}

@end
