//
//  PushDownView.h
//  WGPushBorder
//
//  Created by apple on 2016/12/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PushDownView : UIView

- (void)show;

@end
