//
//  TransformView.h
//  WGPushBorder
//
//  Created by apple on 2016/12/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TransformView : UIView

@property (nonatomic, strong) UIColor *lineColor;
@property (nonatomic, strong) UIColor *titleColor;
@property (nonatomic, strong) UIFont *titleFont;
@property (nonatomic, strong) UIColor *commitColor;
@property (nonatomic, strong) UIColor *cancleColor;
@property (nonatomic, strong) UIFont *commitFont;
@property (nonatomic, strong) UIFont *cancleFont;

- (instancetype)initWithFrame:(CGRect)frame titleText:(NSString *)titleText;

- (void)show;

- (void)hide;

@end
