//
//  StrongDisplayView.h
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    DoubleButtonCenter,
    SingleButtonCenter,
    DoubleButtonBottom,
} DisplayButtonType;

typedef enum : NSUInteger {
    OnlyHasTitle,
    OnlyHasDetailText,
    BothHasTitleAndDetailText,
    BothDotHasTitleAndDetailText,
} TitleType;

@protocol StrongDisplayDelegate <NSObject>

- (void)commit:(NSInteger)index;

- (void)cancle:(NSInteger)index;

@end

@interface StrongDisplayView : UIView

@property (nonatomic, strong) UIColor *commitButtonColor;
@property (nonatomic, strong) UIColor *cancleButtonColor;

@property (nonatomic, assign) TitleType titleType;
@property (nonatomic, assign) DisplayButtonType displayType;

@property (nonatomic, assign) id<StrongDisplayDelegate> DisplayDelegate;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title detailtext:(NSString *)detailText commitTitle:(NSString *)commitTitle cancleTitle:(NSString *)cancleTitle;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title detailText:(NSString *)detailText commitTitle:(NSString *)commitTitle;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title commitText:(NSString *)commitText cancleText:(NSString *)cancleText;

- (void)show;
- (void)hide;

@end
