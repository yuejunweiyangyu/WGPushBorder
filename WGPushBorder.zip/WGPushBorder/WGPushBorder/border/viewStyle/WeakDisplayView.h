//
//  WeakDisplayView.h
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    displayAtTop,
    displayAtCenter,
} displayPosition;

@interface WeakDisplayView : UIView

/* 文字出现的位置 */
@property (nonatomic, assign) displayPosition position;

/* 文字的颜色 */
@property (nonatomic, strong) UIColor *labelColor;

/* 文字的大小 */
@property (nonatomic, strong) UIFont *labelFont;

/* 背景透明度 */
@property (nonatomic, assign) CGFloat backAlpha;

/* 弹框的宽度 */
@property (nonatomic, assign) CGFloat labelWidth;

- (void)show;

- (void)hideDisplayLabel;

- (instancetype)initWithFrame:(CGRect)frame titleText:(NSString *)titleText;

@end
