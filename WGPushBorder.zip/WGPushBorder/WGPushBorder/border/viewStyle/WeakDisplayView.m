//
//  WeakDisplayView.m
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "WeakDisplayView.h"

@interface WeakDisplayView(){
    NSString *_titleText;
}

/* 遮罩 */
@property (nonatomic, strong) UIView *backView;

/* 显示的弹框 */
@property (nonatomic, strong) UILabel *displayLabel;


@end

@implementation WeakDisplayView

- (instancetype)initWithFrame:(CGRect)frame titleText:(NSString *)titleText{
    if (self = [super initWithFrame:frame]) {
        _titleText = titleText;
        [self initSomeSettings];
        [self addSubViews];
    }
    return self;
}

- (void)initSomeSettings{
    self.labelColor = [UIColor whiteColor];
    self.labelFont = [UIFont systemFontOfSize:17];
    self.backAlpha = 0.4;
    self.position = displayAtCenter; //默认显示在中间
}

- (void)addSubViews{
    [self addSubview:self.displayLabel];
    self.displayLabel.center = self.center;
    [self.displayLabel sizeToFit];
}
- (void)show{
    self.displayLabel.hidden = NO;
}
- (void)hideDisplayLabel{
    [UIView animateWithDuration:0.4 animations:^{
        self.displayLabel.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
- (void)setPosition:(displayPosition)position{
    switch (position) {
        case displayAtTop:
        {
            self.displayLabel.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), 20);
        }
            break;
        case displayAtCenter:
        {
            self.displayLabel.center = self.center;
            [self.displayLabel sizeToFit];
        }
            break;
        default:
            break;
    }
}
- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] initWithFrame:self.bounds];
        _backView.backgroundColor = [UIColor blackColor];
        _backView.alpha = 0.4;
    }
    return _backView;
}

- (UILabel *)displayLabel{
    if (!_displayLabel) {
        _displayLabel = [[UILabel alloc] init];
        _displayLabel.textAlignment = NSTextAlignmentCenter;
        _displayLabel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:self.backAlpha];
        _displayLabel.numberOfLines = 0;
        _displayLabel.layer.cornerRadius = 8;
        _displayLabel.clipsToBounds = YES;
        _displayLabel.hidden = YES;
        _displayLabel.textColor = self.labelColor;
        _displayLabel.font = self.labelFont;
        _displayLabel.text = _titleText;
    }
    return _displayLabel;
}



@end
