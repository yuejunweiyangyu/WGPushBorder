//
//  PushDownView.m
//  WGPushBorder
//
//  Created by apple on 2016/12/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "PushDownView.h"
#import "WGBorderConst.h"

#define view_width CGRectGetWidth(self.frame)
#define view_height CGRectGetHeight(self.frame)
@interface PushDownView()

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *backView;

@end

@implementation PushDownView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.backView];
        [self addSubview:self.scrollView];
        self.scrollView.layer.anchorPoint = CGPointMake(0.5, 0);
        self.scrollView.transform = CGAffineTransformMakeScale(1, 0);
    }
    return self;
}

- (void)show{
    [UIView animateWithDuration:0.4 animations:^{
        self.backView.alpha = 0.4;
        self.scrollView.transform = CGAffineTransformIdentity;
    }];
}
- (void)hide{
    [UIView animateWithDuration:0.4 animations:^{
        self.backView.alpha = 0;
        self.scrollView.transform = CGAffineTransformMakeScale(1, 0.00001);
    }];
}
- (UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(view_width/2 - PUSH_VIEW_WIDTH/2, 0, PUSH_VIEW_WIDTH, PUSH_VIEW_WIDTH)];
        _scrollView.backgroundColor = [UIColor whiteColor];
        for (int i = 0; i<10; i++) {
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, i * 50, CGRectGetWidth(_scrollView.frame), 50)];
            label.text = [NSString stringWithFormat:@"%d",i];
            label.textColor = [UIColor darkGrayColor];
            label.textAlignment = NSTextAlignmentCenter;
            [_scrollView addSubview:label];
        }
        _scrollView.contentSize = CGSizeMake(0, 500);
    }
    return _scrollView;
}
- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] initWithFrame:self.frame];
        _backView.backgroundColor = [UIColor blackColor];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hide)];
        [_backView addGestureRecognizer:tap];
        _backView.alpha = 0;
    }
    return _backView;
}

@end
