//
//  WGBorderConst.h
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

UIKIT_EXTERN const CGFloat BUTTON_HEIGHT;

UIKIT_EXTERN const CGFloat PUSH_VIEW_WIDTH;

UIKIT_EXTERN const CGFloat TITLE_LABEL_FONT;
