//
//  WGBorderConst.m
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//


#import <UIKit/UIKit.h>

const CGFloat BUTTON_HEIGHT = 50.0f;

const CGFloat PUSH_VIEW_WIDTH = 200.0f;

const CGFloat TITLE_LABEL_FONT = 17.0f;
