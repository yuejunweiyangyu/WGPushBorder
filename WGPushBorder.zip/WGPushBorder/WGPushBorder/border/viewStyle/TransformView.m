//
//  TransformView.m
//  WGPushBorder
//
//  Created by apple on 2016/12/1.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "TransformView.h"
#import "WGBorderConst.h"

#define view_width CGRectGetWidth(self.frame)
#define view_height CGRectGetHeight(self.frame)
@interface TransformView(){
    NSString *_titleText;
}

@property (nonatomic, strong) UIView *backView;
@property (nonatomic, strong) UIView *pushView;
@property (nonatomic, strong) UILabel *horLabel;
@property (nonatomic, strong) UILabel *verticalLabel;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *commitButton;
@property (nonatomic, strong) UIButton *cancleButton;

@end

@implementation TransformView

- (instancetype)initWithFrame:(CGRect)frame titleText:(NSString *)titleText{
    if (self = [super initWithFrame:frame]) {
        _titleText = titleText;
        [self initSomeSettings];
        [self addSubViews];
    }
    return self;
}

- (void)initSomeSettings{
    self.lineColor = [UIColor groupTableViewBackgroundColor];
    self.titleColor = [UIColor darkGrayColor];
    self.titleFont = [UIFont systemFontOfSize:15];
    self.commitColor = [UIColor redColor];
    self.commitFont = [UIFont systemFontOfSize:15];
    self.cancleColor = [UIColor darkGrayColor];
    self.cancleFont = [UIFont systemFontOfSize:15];
}

- (void)addSubViews{
    [self addSubview:self.backView];
    CGFloat push_height = [self calculate:_titleText] + 80;
    self.pushView.frame = CGRectMake(view_width/2 - PUSH_VIEW_WIDTH/2, view_height/2 - push_height/2, PUSH_VIEW_WIDTH, push_height);
    self.pushView.transform = CGAffineTransformMakeScale(0, 0);
    //self.pushView.layer.anchorPoint = CGPointMake(PUSH_VIEW_WIDTH/2, push_height/2);
    [self addSubview:self.pushView];
    [self.pushView addSubview:self.titleLabel];
    [self.pushView addSubview:self.horLabel];
    [self.pushView addSubview:self.verticalLabel];
    [self.pushView addSubview:self.commitButton];
    [self.pushView addSubview:self.cancleButton];
}

- (CGFloat)calculate:(NSString *)text{
    return [text boundingRectWithSize:CGSizeMake(PUSH_VIEW_WIDTH, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.titleFont} context:nil].size.height;
}

- (void)show{
    [UIView animateWithDuration:0.4 animations:^{
        self.backView.alpha = 0.4;
        self.pushView.transform = CGAffineTransformMakeScale(1, 1);
    }];
}

- (void)hide{
    [UIView animateWithDuration:0.4 animations:^{
        self.backView.alpha = 0;
        self.pushView.transform = CGAffineTransformMakeScale(0.000001, 0.000001);
    }];
}
- (void)commitAction{
    [self hide];
}

- (void)cancleAction{
    [self hide];
}



- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] initWithFrame:self.frame];
        _backView.backgroundColor = [UIColor blackColor];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hide)];
        [_backView addGestureRecognizer:tap];
        _backView.alpha = 0;
    }
    return _backView;
}
- (UIView *)pushView{
    if (!_pushView) {
        _pushView = [[UIView alloc] init];
        _pushView.backgroundColor = [UIColor clearColor];
    }
    return _pushView;
}
- (UILabel *)horLabel{
    if (!_horLabel) {
        _horLabel = [[UILabel alloc] init];
        _horLabel.frame = CGRectMake(0, CGRectGetMaxY(self.titleLabel.frame), PUSH_VIEW_WIDTH, 1);
        _horLabel.backgroundColor = self.lineColor;
    }
    return _horLabel;
}
- (UILabel *)verticalLabel{
    if (!_verticalLabel) {
        _verticalLabel = [[UILabel alloc] init];
        _verticalLabel.frame = CGRectMake(PUSH_VIEW_WIDTH/2 - 1, CGRectGetMaxY(self.horLabel.frame), 1, BUTTON_HEIGHT);
        _verticalLabel.backgroundColor = self.lineColor;
    }
    return _verticalLabel;
}
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.frame = CGRectMake(0, 0, PUSH_VIEW_WIDTH, 30+[self calculate:_titleText]);
        _titleLabel.backgroundColor = [UIColor whiteColor];
        _titleLabel.text = _titleText;
        _titleLabel.textColor = self.titleColor;
        _titleLabel.font = self.titleFont;
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.numberOfLines = 0;
    }
    return _titleLabel;
}


- (UIButton *)commitButton{
    if (!_commitButton) {
        _commitButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.horLabel.frame), PUSH_VIEW_WIDTH/2-1, BUTTON_HEIGHT);
        [_commitButton setTitle:@"确定" forState:UIControlStateNormal];
        _commitButton.backgroundColor = [UIColor whiteColor];
        [_commitButton setTitleColor:self.commitColor forState:UIControlStateNormal];
        [_commitButton addTarget:self action:@selector(commitAction) forControlEvents:UIControlEventTouchUpInside];
        _commitButton.titleLabel.font = self.commitFont;
    }
    return _commitButton;
}

- (UIButton *)cancleButton{
    if (!_cancleButton) {
        _cancleButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _cancleButton.frame = CGRectMake(CGRectGetMaxX(self.verticalLabel.frame), CGRectGetMaxY(self.horLabel.frame), PUSH_VIEW_WIDTH/2, BUTTON_HEIGHT);
        [_cancleButton setTitle:@"取消" forState:UIControlStateNormal];
        [_cancleButton setTitleColor:self.cancleColor forState:UIControlStateNormal];
        _cancleButton.backgroundColor = [UIColor whiteColor];
        [_cancleButton addTarget:self action:@selector(cancleAction) forControlEvents:UIControlEventTouchUpInside];
        _cancleButton.titleLabel.font = self.cancleFont;
    }
    return _cancleButton;
}

@end
