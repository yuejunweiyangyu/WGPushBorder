//
//  StrongDisplayView.m
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "StrongDisplayView.h"
#import "WGBorderConst.h"

#define view_width CGRectGetWidth(self.frame)
#define view_height CGRectGetHeight(self.frame)
@interface StrongDisplayView()
{
    NSString *_titleText;
    NSString *_detailText;
    NSString *_commitText;
    NSString *_cancleText;
}

@property (nonatomic, strong) UIView *backView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *titleLineLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UILabel *detailLineLabel;
@property (nonatomic, strong) UIButton *commitButton;
@property (nonatomic, strong) UIButton *cancleButton;

@property (nonatomic, strong) UIView *pushView;

@end

@implementation StrongDisplayView

/* 有确定取消按钮 */
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title detailtext:(NSString *)detailText commitTitle:(NSString *)commitTitle cancleTitle:(NSString *)cancleTitle{
    if (self = [super initWithFrame:frame]) {
        [self customTitle:title detailText:detailText];
        _titleText = title;
        _detailText = detailText;
        _commitText = commitTitle;
        _cancleText = cancleTitle;
        self.displayType = DoubleButtonCenter;
        [self initSomeSettings];
    }
    return self;
    
}
/* 只有确定按钮 */
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title detailText:(NSString *)detailText commitTitle:(NSString *)commitTitle{
    if (self = [super initWithFrame:frame]) {
        [self customTitle:title detailText:detailText];
        _titleText = title;
        _detailText = detailText;
        _commitText = commitTitle;
        self.displayType = SingleButtonCenter;
        [self initSomeSettings];
    }
    return self;
}
/* 从底部出现 */
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title commitText:(NSString *)commitText cancleText:(NSString *)cancleText{
    if (self = [super initWithFrame:frame]) {
        _titleText = title;
        _commitText = commitText;
        _cancleText = cancleText;
        [self customTitle:title detailText:nil];
        self.displayType = DoubleButtonBottom;
        [self initSomeSettings];
    }
    return self;
}

- (void)customTitle:(NSString *)title detailText:(NSString *)detailText{
    if ((title == nil || [title isEqualToString:@""]) && (detailText == nil || [detailText isEqualToString:@""])) {
        self.titleType = BothDotHasTitleAndDetailText;
    }else if ((title == nil || [title isEqualToString:@""]) && (detailText != nil && ![detailText isEqualToString:@""])){
        self.titleType = OnlyHasDetailText;
    }else if((title != nil && ![title isEqualToString:@""]) && (detailText == nil || [detailText isEqualToString:@""])){
        self.titleType = OnlyHasTitle;
    }else{
        self.titleType = BothHasTitleAndDetailText;
    }
}

- (void)initSomeSettings{
    self.commitButtonColor = [UIColor redColor];
    self.cancleButtonColor = [UIColor darkGrayColor];
    switch (self.displayType) {
        case DoubleButtonBottom:
        {
            switch (self.titleType) {
                case BothDotHasTitleAndDetailText:
                    
                    break;
                case OnlyHasTitle:
                {
                    [self addSubview:self.backView];
                    CGFloat push_height = 135 + [self calculate:_titleText];
                    self.pushView.frame = CGRectMake(0, view_height, view_width, push_height);
                    [self addSubview:self.pushView];
                    self.titleLabel.frame = CGRectMake(0, 0, view_width, [self calculate:_titleText] + 23);
                    [self.pushView addSubview:self.titleLabel];
                    self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.titleLabel.frame) + 10, view_width, BUTTON_HEIGHT);
                    [self.pushView addSubview:self.commitButton];
                    self.cancleButton.frame = CGRectMake(0, CGRectGetMaxY(self.commitButton.frame) + 2, view_width, BUTTON_HEIGHT);
                    [self.pushView addSubview:self.cancleButton];
                    [self show];
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case SingleButtonCenter:
        {
            switch (self.titleType) {
                case OnlyHasTitle:
                {
                    [self addSubViews:YES isSingleTitle:YES isTitle:YES];
                }
                    break;
                case OnlyHasDetailText:
                {
                    [self addSubViews:YES isSingleTitle:YES isTitle:NO];
                }
                    break;
                case BothHasTitleAndDetailText:
                {
                    [self addSubViews:YES isSingleTitle:NO isTitle:YES];
                }
                    break;
                case BothDotHasTitleAndDetailText:
                    
                    break;
                default:
                    break;
            }
        }
            break;
        case DoubleButtonCenter:
        {
            switch (self.titleType) {
                case OnlyHasTitle:
                {
                    [self addSubViews:NO isSingleTitle:YES isTitle:YES];
                }
                    break;
                case OnlyHasDetailText:
                {
                    [self addSubViews:NO isSingleTitle:YES isTitle:NO];
                }
                    break;
                case BothHasTitleAndDetailText:
                {
                    [self addSubViews:NO isSingleTitle:NO isTitle:YES];
                }
                    break;
                case BothDotHasTitleAndDetailText:
                    
                    break;
                default:
                    break;
            }
        }
            break;
        default:
            break;
    }
}
- (void)addSubViews:(BOOL)isOneButton isSingleTitle:(BOOL)singleTitle isTitle:(BOOL)isTitle{
    [self addSubview:self.backView];
    self.pushView.alpha = 0;
    [self addSubview:self.pushView];
    [self.pushView addSubview:self.titleLabel];
    [self.pushView addSubview:self.titleLineLabel];
    [self.pushView addSubview:self.detailLabel];
    [self.pushView addSubview:self.detailLineLabel];
    [self.pushView addSubview:self.commitButton];
    [self.pushView addSubview:self.cancleButton];
    if (isOneButton) {
        [self customSingleTitle:singleTitle isTitle:isTitle Hidden:YES];
    }else{
        [self customSingleTitle:singleTitle isTitle:isTitle Hidden:NO];
    }
}

- (void)customSingleTitle:(BOOL)singleTitle isTitle:(BOOL)isTitle Hidden:(BOOL)hidden{
    if (singleTitle) {
        
        if (isTitle) {
            CGFloat push_height = 80 + [self calculate:_titleText];
            self.detailLabel.hidden = YES;
            self.detailLineLabel.hidden = YES;
            
            self.pushView.frame = CGRectMake(view_width / 2 - PUSH_VIEW_WIDTH / 2, view_height / 2 - push_height / 2, PUSH_VIEW_WIDTH, push_height);
            self.titleLabel.frame = CGRectMake(0, 0, PUSH_VIEW_WIDTH, [self calculate:_titleText] + 29);
            self.titleLineLabel.frame = CGRectMake(0, CGRectGetMaxY(self.titleLabel.frame), PUSH_VIEW_WIDTH, 1);
            if (hidden) {
                self.cancleButton.hidden = YES;
                self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.titleLineLabel.frame), PUSH_VIEW_WIDTH, 50);
            }else{
                self.cancleButton.hidden = NO;
                self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.titleLineLabel.frame), PUSH_VIEW_WIDTH/2, 50);
                self.cancleButton.frame = CGRectMake(CGRectGetMaxX(self.commitButton.frame), CGRectGetMaxY(self.titleLineLabel.frame), PUSH_VIEW_WIDTH/2, 50);
            }
            [self show];
        }else{
            self.titleLabel.hidden = YES;
            self.titleLineLabel.hidden = YES;
            CGFloat push_height = 80 + [self calculate:_detailText];
            
            self.pushView.frame = CGRectMake(view_width / 2 - PUSH_VIEW_WIDTH / 2, view_height / 2 - push_height / 2, PUSH_VIEW_WIDTH, push_height);
            self.detailLabel.frame = CGRectMake(0, 0, PUSH_VIEW_WIDTH, [self calculate:_detailText] + 29);
            self.detailLineLabel.frame = CGRectMake(0, CGRectGetMaxY(self.detailLineLabel.frame), PUSH_VIEW_WIDTH, 1);
            if (hidden) {
                self.cancleButton.hidden = YES;
                self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.detailLabel.frame), PUSH_VIEW_WIDTH, 50);
            }else{
                self.cancleButton.hidden = NO;
                self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.detailLineLabel.frame), PUSH_VIEW_WIDTH/2, 50);
                self.cancleButton.frame = CGRectMake(CGRectGetMaxX(self.commitButton.frame), CGRectGetMaxY(self.detailLineLabel.frame), PUSH_VIEW_WIDTH/2, 50);
            }
            [self show];
        }
    }else{
        CGFloat push_height = 110 + [self calculate:_titleText] + [self calculate:_detailText];
        self.pushView.frame = CGRectMake(view_width / 2 - PUSH_VIEW_WIDTH / 2, view_height / 2 - push_height / 2, PUSH_VIEW_WIDTH, push_height);
        self.titleLabel.frame = CGRectMake(0, 0, PUSH_VIEW_WIDTH, 29 + [self calculate:_titleText]);
        self.titleLineLabel.frame = CGRectMake(0, CGRectGetMaxY(self.titleLabel.frame), PUSH_VIEW_WIDTH, 1);
        self.detailLabel.frame = CGRectMake(0, CGRectGetMaxY(self.titleLineLabel.frame), PUSH_VIEW_WIDTH, 29 + [self calculate:_detailText]);
        self.detailLineLabel.frame = CGRectMake(0, CGRectGetMaxY(self.detailLabel.frame), PUSH_VIEW_WIDTH, 1);
        if (hidden) {
            self.cancleButton.hidden = YES;
            self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.detailLabel.frame), PUSH_VIEW_WIDTH, 50);
        }else{
            self.cancleButton.hidden = NO;
            self.commitButton.frame = CGRectMake(0, CGRectGetMaxY(self.detailLineLabel.frame), PUSH_VIEW_WIDTH/2, 50);
            self.cancleButton.frame = CGRectMake(CGRectGetMaxX(self.commitButton.frame), CGRectGetMaxY(self.detailLineLabel.frame), PUSH_VIEW_WIDTH/2, 50);
        }
        [self show];
        
    }
   
}

- (void)show{
    if (self.displayType == DoubleButtonBottom) {
        CGFloat push_height = 135 + [self calculate:_titleText];
        [UIView animateWithDuration:0.4 animations:^{
            self.backView.alpha = 0.3;
            self.pushView.frame = CGRectMake(0, view_height - push_height, view_width, push_height);
        } completion:^(BOOL finished) {
            
        }];
    }else if (self.displayType == SingleButtonCenter){
        [UIView animateWithDuration:0.4 animations:^{
            self.backView.alpha = 0.3;
            self.pushView.alpha = 1;
        }];
    }else{
        [UIView animateWithDuration:0.4 animations:^{
            self.backView.alpha = 0.3;
            self.pushView.alpha = 1;
        }];
    }
}

- (void)hide{
    if (self.displayType == DoubleButtonBottom) {
        CGFloat push_height = 135 + [self calculate:_titleText];
        [UIView animateWithDuration:0.4 animations:^{
            self.backView.alpha = 0;
            self.pushView.frame = CGRectMake(0, view_height, view_width, push_height);
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }else if (self.displayType == SingleButtonCenter){
        [UIView animateWithDuration:0.4 animations:^{
            self.backView.alpha = 0;
            self.pushView.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }else{
        [UIView animateWithDuration:0.4 animations:^{
            self.backView.alpha = 0;
            self.pushView.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }
}

- (CGFloat)calculate:(NSString *)text{
    return [text boundingRectWithSize:CGSizeMake(CGRectGetWidth(self.frame), MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size.height;
}
- (void)commitClick{
    if (self.DisplayDelegate && [self.DisplayDelegate respondsToSelector:@selector(commit:)]) {
        switch (self.displayType) {
            case DoubleButtonCenter:
                [self.DisplayDelegate commit:1];
                break;
            case SingleButtonCenter:
                [self.DisplayDelegate commit:2];
                break;
            case DoubleButtonBottom:
                [self.DisplayDelegate commit:3];
                break;
            default:
                break;
        }
        
    }
}
- (void)cancleClick{
    if (self.DisplayDelegate && [self.DisplayDelegate respondsToSelector:@selector(cancle:)]) {
        switch (self.displayType) {
            case DoubleButtonCenter:
                [self.DisplayDelegate commit:1];
                break;
            case SingleButtonCenter:
                break;
            case DoubleButtonBottom:
                [self.DisplayDelegate commit:3];
                break;
            default:
                break;
        }
    }
}

- (void)backViewCLick{
    [UIView animateWithDuration:0.4 animations:^{
        self.backView.alpha = 0 ;
        self.pushView.frame = CGRectMake(0, view_height, view_width, 135 + [self calculate:_titleText]);
    }];
}

/* 遮罩 */
- (UIView *)backView{
    if (!_backView) {
        _backView = [[UIView alloc] initWithFrame:self.frame];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backViewCLick)];
        [_backView addGestureRecognizer:tap];
        _backView.backgroundColor = [UIColor blackColor];
        _backView.alpha = 0;
    }
    return _backView;
}
- (UILabel *)titleLabel{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor darkGrayColor];
        _titleLabel.text = _titleText;
        _titleLabel.backgroundColor = [UIColor whiteColor];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.numberOfLines = 0;
    }
    return _titleLabel;
}
- (UILabel *)titleLineLabel{
    if (!_titleLineLabel) {
        _titleLineLabel = [[UILabel alloc] init];
        _titleLineLabel.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _titleLineLabel;
}
- (UILabel *)detailLabel{
    if (!_detailLabel) {
        _detailLabel = [[UILabel alloc] init];
        _detailLabel.textColor = [UIColor darkGrayColor];
        _detailLabel.backgroundColor = [UIColor whiteColor];
        _detailLabel.numberOfLines = 0;
        _detailLabel.textAlignment = NSTextAlignmentCenter;
        _detailLabel.text = _detailText;
    }
    return _detailLabel;
}
- (UILabel *)detailLineLabel{
    if (!_detailLineLabel) {
        _detailLineLabel = [[UILabel alloc] init];
        _detailLineLabel.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _detailLineLabel;
}
- (UIButton *)commitButton{
    if (!_commitButton) {
        _commitButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _commitButton.backgroundColor = [UIColor whiteColor];
        [_commitButton addTarget:self action:@selector(commitClick) forControlEvents:UIControlEventTouchUpInside];
        [_commitButton setTitleColor:self.commitButtonColor forState:UIControlStateNormal];
        [_commitButton setTitle:_commitText forState:UIControlStateNormal];
    }
    return _commitButton;
}

- (UIButton *)cancleButton{
    if (!_cancleButton) {
        _cancleButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _cancleButton.backgroundColor = [UIColor whiteColor];
        [_cancleButton addTarget:self action:@selector(cancleClick) forControlEvents:UIControlEventTouchUpInside];
        [_cancleButton setTitleColor:self.cancleButtonColor forState:UIControlStateNormal];
        [_cancleButton setTitle:_cancleText forState:UIControlStateNormal];
    }
    return _cancleButton;
}

- (UIView *)pushView{
    if (!_pushView) {
        _pushView = [[UIView alloc] init];
        _pushView.backgroundColor = [UIColor clearColor];
    }
    return _pushView;
}

@end
