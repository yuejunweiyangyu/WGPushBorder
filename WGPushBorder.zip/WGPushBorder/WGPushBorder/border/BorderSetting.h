//
//  BorderSetting.h
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BorderSetting : NSObject

+ (BorderSetting *)shareBorderSetting;

- (void)showWeakDisplayView:(UIView *)viewController titleText:(NSString *)titleText;

@end
