//
//  MainViewController.m
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "MainViewController.h"
#import "UIBarButtonItem+WGBarButton.h"
#import "BorderSetting.h"
#import "StrongDisplayView.h"
#import "ThirdTypeView.h"
#import "TransformView.h"
#import "PushDownView.h"

@interface MainViewController ()<StrongDisplayDelegate>

@property (nonatomic, strong) StrongDisplayView *bottomView;
@property (nonatomic, strong) StrongDisplayView *centerView;
@property (nonatomic, strong) StrongDisplayView *centerDoubleView;

@property (nonatomic, strong) ThirdTypeView *thirdTypeView;

@property (nonatomic, strong) TransformView *transformView;

@property (nonatomic, strong) PushDownView *pushDownView;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = self.titleName;
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem initWithTitle:self.title target:self action:@selector(btnClick)];
}

- (void)btnClick{
    if ([self.titleName compare:@"弱提示"] == NSOrderedSame) {
        [[BorderSetting shareBorderSetting] showWeakDisplayView:self.view titleText:@"对萨法撒到家乐福"];
    }else if ([self.titleName compare:@"强提示"] == NSOrderedSame){
        [self.view addSubview:self.thirdTypeView];
    }else if ([self.titleName compare:@"放大"] == NSOrderedSame){
        [self.view addSubview:self.transformView];
        [self.transformView show];
    }else{
        [self.view addSubview:self.pushDownView];
        [self.pushDownView show];
    }
}

- (PushDownView *)pushDownView{
    if (!_pushDownView) {
        _pushDownView = [[PushDownView alloc] initWithFrame:self.view.frame];
    }
    return _pushDownView;
}

- (TransformView *)transformView{
    if (!_transformView) {
        _transformView = [[TransformView alloc] initWithFrame:self.view.frame titleText:@"很简单的"];
    }
    return _transformView;
}

#pragma mark   ==================懒加载============
- (StrongDisplayView *)bottomView{
    if (!_bottomView) {
        _bottomView = [[StrongDisplayView alloc] initWithFrame:self.view.frame title:@"写这个这么容易啊" commitText:@"确定" cancleText:@"取消"];
        _bottomView.DisplayDelegate = self;
        
    }
    return _bottomView;
}

- (StrongDisplayView *)centerView{
    if (!_centerView) {
        _centerView = [[StrongDisplayView alloc] initWithFrame:self.view.frame title:@"写这个这么容易啊" detailText:@"写这个这么容易啊" commitTitle:@"确定"];
        _centerView.DisplayDelegate = self;
    }
    return _centerView;
}

- (StrongDisplayView *)centerDoubleView{
    if (!_centerDoubleView) {
        _centerDoubleView = [[StrongDisplayView alloc] initWithFrame:self.view.frame title:@"写这个这么容易啊" detailtext:@"写这个这么容易啊" commitTitle:@"确定" cancleTitle:@"取消"];
        _centerDoubleView.DisplayDelegate = self;
    }
    return _centerDoubleView;
}


#pragma mark ===============delegate================

- (void)commit:(NSInteger)index{
    switch (index) {
        case 1:
            [self.centerDoubleView hide];
            self.centerDoubleView = nil;
            break;
        case 2:
            [self.centerView hide];
            self.centerView = nil;
            break;
        case 3:
            [self.bottomView hide];
            self.bottomView = nil;
            break;
        default:
            break;
    }
    
}

- (void)cancle:(NSInteger)index{
    switch (index) {
        case 1:
            [self.centerDoubleView hide];
            self.centerDoubleView = nil;
            break;
        case 2:
            break;
        case 3:
            [self.bottomView hide];
            self.bottomView = nil;
            break;
        default:
            break;
    }
    
}


- (ThirdTypeView *)thirdTypeView{
    __weak typeof(self) weakSelf = self;
    if (!_thirdTypeView) {
        _thirdTypeView = [ThirdTypeView showThirdTypeView];
        _thirdTypeView.frame = CGRectMake(0, 64, 375, 50);
        _thirdTypeView.click = ^(NSInteger index){
            switch (index) {
                case 3:
                    [weakSelf.view addSubview:weakSelf.centerDoubleView];
                    break;
                case 4:
                    [weakSelf.view addSubview:weakSelf.centerView];
                    break;
                case 5:
                    [weakSelf.view addSubview:weakSelf.bottomView];
                    break;
                default:
                    break;
            }
        };
    }
    return _thirdTypeView;
}

@end
