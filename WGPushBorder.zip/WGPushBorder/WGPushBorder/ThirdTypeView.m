//
//  ThirdTypeView.m
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ThirdTypeView.h"

@implementation ThirdTypeView

+ (instancetype)showThirdTypeView{
    return [[[NSBundle mainBundle] loadNibNamed:@"ThirdTypeView" owner:nil options:nil] firstObject];
}
- (IBAction)buttonClick:(UIButton *)sender {
    if (self.click) {
        self.click(sender.tag);
    }
}

@end
