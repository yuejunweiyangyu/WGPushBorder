//
//  UIBarButtonItem+WGBarButton.h
//  WGPushBorder
//
//  Created by apple on 2016/11/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (WGBarButton)

+ (instancetype)initWithTitle:(NSString *)title target:(id)target action:(SEL)action;

@end
